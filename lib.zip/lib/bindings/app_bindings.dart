import 'package:get/get.dart';
import '../controllers/auth_controller.dart';
import '../controllers/progress_controller.dart';
import '../controllers/quiz_controller.dart';
import '../controllers/quiz_history_controller.dart';
import '../controllers/search_controller.dart';
import '../controllers/streak_controller.dart';
import '../controllers/theory_controller.dart';

class AppBindings implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AuthController>(() => AuthController(), fenix: true);
    Get.lazyPut<SearchController>(() => SearchController(), fenix: true);
    Get.lazyPut<TheoryController>(() => TheoryController(), fenix: true);
    Get.put(ProgressController(), permanent: true);
    Get.put(StreakController(), permanent: true);
    Get.put(QuizHistoryController(), permanent: true);
    Get.put(QuizController(), permanent: true); // <== THÊM DÒNG NÀY
  }
}