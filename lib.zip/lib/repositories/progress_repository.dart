import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../model/lesson_completion_model.dart';
import '../model/progress_model.dart';

class ProgressRepository {
  // ✅ Single source of truth cho host và các base
  static const String host = 'http://192.168.1.118:8080'; // chỉnh 1 lần ở đây

  static String get authBase => '$host/api/auth';
  static String get progressBase => '$host/api/progress';

  // ⚠️ Streak/Quiz: tách qua repository riêng (StreakRepository / QuizHistoryRepository)
  // static String get streakBase => '$host/api/attendance'; // dùng ở StreakRepository
  // static String get quizBase   => '$host/api/quiz';       // dùng ở QuizHistoryRepository

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('authToken');
  }

  // Helper build URL cho progress
  static Uri _u(String path) => Uri.parse('$progressBase$path');

  Future<void> debugToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('authToken');
    final userId = prefs.getInt('userId');
    final tail = token == null ? '' : token.substring(math.max(0, token.length - 10));
    print('🔐 Debug Token Info: exists=${token != null}, len=${token?.length ?? 0}, userId=$userId, tail=${token != null ? '...$tail' : 'null'}');
  }

  Future<http.Response> _authenticatedRequest(
      Uri url, {
        String method = 'GET',
        Map<String, dynamic>? body,
      }) async {
    try {
      final token = await ProgressRepository.getToken();
      if (token == null) {
        throw Exception('Token not found');
      }

      final headers = <String, String>{
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      };

      late http.Response res;
      if (method == 'GET') {
        res = await http.get(url, headers: headers).timeout(const Duration(seconds: 15));
      } else if (method == 'POST') {
        res = await http
            .post(url, headers: headers, body: body == null ? null : jsonEncode(body))
            .timeout(const Duration(seconds: 20));
      } else if (method == 'DELETE') {
        res = await http.delete(url, headers: headers).timeout(const Duration(seconds: 15));
      } else {
        throw Exception('Method not supported');
      }
      return res;
    } catch (e) {
      print('💥 Error in _authenticatedRequest($method $url): $e');
      rethrow;
    }
  }

  // === Lesson completion ===
  Future<LessonCompletion> completeLesson(int userId, int lessonId) async {
    final res = await _authenticatedRequest(
      _u('/complete-lesson'),
      method: 'POST',
      body: {'userId': userId, 'lessonId': lessonId},
    );
    if (res.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(res.body);
      if (data['success'] == true) return LessonCompletion.fromJson(data['data']);
      throw Exception(data['message'] ?? 'Unknown error');
    }
    throw Exception('Failed to complete lesson: ${res.statusCode}');
  }

  Future<void> uncompleteLesson(int userId, int lessonId) async {
    final res = await _authenticatedRequest(
      _u('/uncomplete-lesson/user/$userId/lesson/$lessonId'),
      method: 'DELETE',
    );
    if (res.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(res.body);
      if (data['success'] != true) throw Exception(data['message'] ?? 'Unknown error');
      return;
    }
    throw Exception('Failed to uncomplete lesson: ${res.statusCode}');
  }

  Future<bool> checkLessonCompletion(int userId, int lessonId) async {
    final res = await _authenticatedRequest(_u('/check-completion/user/$userId/lesson/$lessonId'));
    if (res.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(res.body);
      if (data['success'] == true) return (data['data']?['completed'] ?? false) as bool;
      throw Exception(data['message'] ?? 'Unknown error');
    }
    throw Exception('Failed to check completion: ${res.statusCode}');
  }

  // === Progress ===
  Future<Progress> getProgressBySubject(int userId, int subjectId) async {
    final res = await _authenticatedRequest(_u('/user/$userId/subject/$subjectId'));
    if (res.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(res.body);
      if (data['success'] == true) return Progress.fromJson(data['data']);
      throw Exception(data['message'] ?? 'Unknown error');
    }
    throw Exception('Failed to get progress: ${res.statusCode}');
  }

  Future<List<Progress>> getProgressByUser(int userId) async {
    final res = await _authenticatedRequest(_u('/user/$userId'));
    if (res.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(res.body);
      if (data['success'] == true) {
        final List<dynamic> list = data['data'] ?? [];
        return list.map((e) => Progress.fromJson(e)).toList();
      }
      throw Exception(data['message'] ?? 'Unknown error');
    }
    throw Exception('Failed to get progress: ${res.statusCode}');
  }

  Future<List<Progress>> getProgressByGrade(int userId, int grade) async {
    final res = await _authenticatedRequest(_u('/user/$userId/grade/$grade'));
    if (res.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(res.body);
      if (data['success'] == true) {
        final List<dynamic> list = data['data'] ?? [];
        return list.map((e) => Progress.fromJson(e)).toList();
      }
      throw Exception(data['message'] ?? 'Unknown error');
    }
    throw Exception('Failed to get progress: ${res.statusCode}');
  }
}
