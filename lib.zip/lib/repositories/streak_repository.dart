// lib/repositories/streak_repository.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../repositories/progress_repository.dart';

class UserStreak {
  final int current;       // số ngày liên tiếp hiện tại
  final int longest;       // kỷ lục
  final int total;         // tổng số ngày đã học
  final DateTime? lastCheckIn;

  UserStreak({
    required this.current,
    required this.longest,
    required this.total,
    required this.lastCheckIn,
  });

  /// Hỗ trợ nhiều key do backend có thể khác tên
  factory UserStreak.fromAnyJson(Map<String, dynamic> j) {
    int _int(dynamic v) => (v is int) ? v : int.tryParse('${v ?? 0}') ?? 0;
    DateTime? _dt(dynamic v) =>
        v == null ? null : DateTime.tryParse(v.toString());

    return UserStreak(
      // alias: current | currentStreak
      current: _int(j['current'] ?? j['currentStreak']),
      // alias: longest | best | bestStreak
      longest: _int(j['longest'] ?? j['best'] ?? j['bestStreak']),
      // alias: total | totalDays
      total: _int(j['total'] ?? j['totalDays']),
      // alias: lastCheckIn | lastActiveDate
      lastCheckIn: _dt(j['lastCheckIn'] ?? j['lastActiveDate']),
    );
  }

  static UserStreak empty() =>
      UserStreak(current: 0, longest: 0, total: 0, lastCheckIn: null);
}

class StreakRepository {
  // ❗ Backend của bạn đang phục vụ ở /api/streak/{userId}
  static String get _base => '${ProgressRepository.host}/api/streak';

  static Future<Map<String, String>> _headers() async {
    final token = await ProgressRepository.getToken();
    return {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  /// GET /api/streak/{userId}
  static Future<UserStreak> fetch(int userId) async {
    final uri = Uri.parse('$_base/$userId');
    final res = await http.get(uri, headers: await _headers())
        .timeout(const Duration(seconds: 12));

    if (res.statusCode == 200) {
      final body = jsonDecode(res.body);
      if (body is Map<String, dynamic>) {
        return UserStreak.fromAnyJson(body);
      }
      // một số backend bọc data:
      if (body is Map && body['data'] is Map<String, dynamic>) {
        return UserStreak.fromAnyJson(body['data'] as Map<String, dynamic>);
      }
      return UserStreak.empty();
    }

    // Backend có thể trả 404 nếu chưa có streak -> coi như 0
    if (res.statusCode == 404) return UserStreak.empty();

    throw Exception('Fetch streak failed ${res.statusCode}: ${res.body}');
  }

  /// POST check-in/online/touch tuỳ backend
  /// Thử tuần tự các path: /online, /check-in, /touch (cái nào có thì dùng)
  static Future<UserStreak> markOnline(int userId) async {
    final candidates = <String>['online', 'check-in', 'touch'];
    final headers = await _headers();

    Object? lastError;

    for (final p in candidates) {
      final uri = Uri.parse('$_base/$userId/$p');
      try {
        final res = await http.post(uri, headers: headers)
            .timeout(const Duration(seconds: 12));
        if (res.statusCode == 200) {
          final body = jsonDecode(res.body);
          if (body is Map<String, dynamic>) {
            // Một số backend trả {success:true,data:{...}}
            final data = (body['data'] is Map<String, dynamic>)
                ? (body['data'] as Map<String, dynamic>)
                : body;
            return UserStreak.fromAnyJson(data);
          }
        }
        // 404 -> endpoint này không tồn tại, thử endpoint kế
        if (res.statusCode == 404) {
          lastError = '404 $p';
          continue;
        }
        // status khác 200/404 -> fail hẳn
        throw Exception('markOnline($p) failed ${res.statusCode}: ${res.body}');
      } catch (e) {
        lastError = e;
        // thử endpoint tiếp theo
        continue;
      }
    }

    throw Exception('No working markOnline endpoint. Last error: $lastError');
  }
}
