import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../model/streak_state.dart';
import '../repositories/streak_repository.dart';

class StreakController extends GetxController {
  final Rx<StreakState> state = StreakState.empty().obs;
  final RxBool isLoading = false.obs;
  final RxBool streakLoaded = false.obs;

  Future<int> _uid() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getInt('userId') ?? 0;
  }

  Future<void> fetchStreak() async {
    try {
      isLoading.value = true;
      final uid = await _uid();
      if (uid == 0) {
        state.value = StreakState.empty();
        streakLoaded.value = true;
        return;
      }
      final j = await StreakRepository.getStreak(uid);
      state.value = StreakState.fromJson(j);
      streakLoaded.value = true;
    } finally {
      isLoading.value = false;
    }
  }

  // alias cho code cũ
  Future<void> loadStreak() => fetchStreak();

  Future<void> markOnline() async {
    final uid = await _uid();
    if (uid == 0) return;
    await StreakRepository.markOnline(uid);
    await fetchStreak();
  }
}
