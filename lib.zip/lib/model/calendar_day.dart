class CalendarDayDTO {
  final DateTime date;
  final bool studied;
  final int minutesStudied;
  final bool isInCurrentStreak;

  CalendarDayDTO({
    required this.date,
    required this.studied,
    required this.minutesStudied,
    required this.isInCurrentStreak,
  });

  factory CalendarDayDTO.fromJson(Map<String, dynamic> json) {
    return CalendarDayDTO(
      date: DateTime.parse(json['date']),
      studied: json['studied'],
      minutesStudied: json['minutesStudied'],
      isInCurrentStreak: json['isInCurrentStreak'],
    );
  }
}