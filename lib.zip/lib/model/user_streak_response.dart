import 'calendar_day.dart';

class UserStreakResponse {
  final int userId;
  final int currentStreak;
  final DateTime? streakStartDate;
  final DateTime? streakEndDate;
  final List<DateTime> streakDays;
  final List<CalendarDayDTO> calendarDays;

  UserStreakResponse({
    required this.userId,
    required this.currentStreak,
    this.streakStartDate,
    this.streakEndDate,
    required this.streakDays,
    required this.calendarDays,
  });

  factory UserStreakResponse.fromJson(Map<String, dynamic> json) {
    return UserStreakResponse(
      userId: json['userId'] is int
          ? json['userId']
          : int.tryParse(json['userId'].toString()) ?? 0,
      currentStreak: json['currentStreak'] ?? 0,
      streakStartDate: json['streakStartDate'] != null
          ? DateTime.parse(json['streakStartDate'].toString())
          : null,
      streakEndDate: json['streakEndDate'] != null
          ? DateTime.parse(json['streakEndDate'].toString())
          : null,
      streakDays: (json['streakDays'] as List? ?? [])
          .map((e) => DateTime.parse(e.toString()))
          .toList(),
      calendarDays: (json['calendarDays'] as List? ?? [])
          .map((e) => CalendarDayDTO.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
    );
  }
}
